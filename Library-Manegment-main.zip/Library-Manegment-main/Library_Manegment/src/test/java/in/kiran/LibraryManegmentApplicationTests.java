package in.kiran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManegmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
