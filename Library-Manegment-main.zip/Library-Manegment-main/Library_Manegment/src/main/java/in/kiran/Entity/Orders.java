package in.kiran.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Orders {

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orderId;
	
    private String userName;
    private String userMail;
    //from Book table 
	 private String title;
	 private String author;
	 private String bookImage;
	 private String price;
	
	
}
