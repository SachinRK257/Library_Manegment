package in.kiran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManegmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManegmentApplication.class, args);
	}

}
