package in.kiran.Infservice;

import java.util.List;

import in.kiran.Entity.Book;

public interface BookService {

	Integer saveBook(Book book);
	
	public List<Book> getAllBooks() ;

}
