package in.kiran.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kiran.Entity.Book;
import in.kiran.Entity.Orders;
import in.kiran.Infservice.BookService;
import in.kiran.repo.BookRepository;

@Service
public class BookServiceImpl implements BookService{

	@Autowired
	BookRepository repo;
	
	@Override
	public Integer saveBook(Book book) {
        
		return repo.save(book).getId();
	}

	@Override
	public List<Book> getAllBooks() {
		
		return repo.findAll();
	}

	public Book getBookById(Integer id) {
		return repo.findById(id).get();
	}

	
	
}
